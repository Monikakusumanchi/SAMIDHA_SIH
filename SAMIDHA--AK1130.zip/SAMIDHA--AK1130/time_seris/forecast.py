# -*- coding: utf-8 -*-
"""
Created on Sat Aug 20 10:45:50 2022

@author: user
"""

import numpy as np
import pickle
import streamlit as st

loaded_model=pickle.load(open('E:\samidha_SIH\time_seris\forecasting.sav', 'rb'))
#import y
#st.write(y)