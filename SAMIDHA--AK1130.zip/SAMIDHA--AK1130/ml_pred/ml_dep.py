# -*- coding: utf-8 -*-
"""
Created on Wed Aug  3 17:56:42 2022

@author: user
"""

import numpy as np
import pickle
import streamlit as st
from sklearn.preprocessing import StandardScaler

loaded_model=pickle.load(open('E:/samidha_SIH/ml_pred/fuel_predection.sav', 'rb'))

input_data=(84.783264,	1015.108167,	9024.415770,	15.986393,	16.170261,	78.969497,	359.735704,	7.155163,	-24.619080,	9.939138	,276.420947	,28.048569,11.629935)
# changing the input_data to numpy array
input_data_as_numpy_array = np.asarray(input_data)

# reshape the array as we are predicting for one instance
input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)

# standardize the input data
scaler = StandardScaler()
scaler.fit(input_data_reshaped)
std_data = scaler.transform(input_data_reshaped)

#print(std_data)

prediction =loaded_model.predict(std_data)
print(prediction)
