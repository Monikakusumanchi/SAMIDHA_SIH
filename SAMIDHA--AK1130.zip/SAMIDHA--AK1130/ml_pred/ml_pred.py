
import flask
#from flask import flask_request
from flask_restful import Resource,Api
import numpy as np
import pandas as pd
import pickle
from flask_cors import CORS
app=flask(__name__)
CORS(app)
api=Api(app)
class predection(Resource):
    def get(self,pred):
        print(pred)"samidha_SIH/ml_pred/ml_pred.py"
        pred=[int(pred)]
        df=pd.DataFrame(pred,columns=['fuel_consumption'])
        model=pickle.load(open('fuel.sav','rb'))
        predection=model.predict(df)
        predection=int(predection[0])
        return str(predection)
class getData(Resource):
    def get(self):
        df=pd.read_csv('E:\samidha_SIH\datasets\indexed-dataFrame.csv')
        #df=__df.rename({})
        res=df.to_json(oreantation='records')
        return res
api.add_resource(getData,'/api')
api.add_resource(predection,'/predection/<int:pred>')
if __name__=='__main__':
    app.run(debug=True)
