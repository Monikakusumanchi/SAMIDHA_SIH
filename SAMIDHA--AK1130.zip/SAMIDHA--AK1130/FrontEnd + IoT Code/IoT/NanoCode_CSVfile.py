
import serial
try:
    arduino = serial.Serial("COM5",baudrate=9600)
    print("hello")
except:
    print('Please check the port')

rawdata=[]
count=0

while count<100 :
    rawdata.append(str(arduino.readline()))
    count += 1

print(rawdata)

def clean(L):
    newl=[]
    for i in range(len(L)):
        temp=L[i][2:]
        newl.append(temp[:-5])
    return newl

cleandata=clean(rawdata)

def write(L):
    file = open("data2.csv",mode = "w")
    for i in range(len(L)):
        file.write(L[i]+'\n')
    file.close()

write(cleandata)    

