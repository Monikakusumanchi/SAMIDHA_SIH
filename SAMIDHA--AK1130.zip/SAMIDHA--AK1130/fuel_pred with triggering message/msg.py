# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 14:55:44 2022

@author: user
"""

import numpy as np
import pickle
import streamlit as st


loaded_model=pickle.load(open('E:/samidha_SIH/fuel_pred/fuel.sav', 'rb'))
def fuel_predict(input_data):
    
    input_data_as_numpy_array = np.asarray(input_data)

# reshape the array as we are predicting for one instance
    input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)

# standardize the input data
    prediction = loaded_model.predict(input_data_reshaped)
    print(prediction)
    actual=0.8
    prediction = loaded_model.predict(input_data_reshaped)
    print(prediction)
    return prediction,st.write("abnormal fuel consumption")
    
    
   
def main():
    st.title('fuel prediction model')
   					
    shaftSpeed=st.text_input('enter shaft speed')
        
    
    
    TWS  =st.text_input('enter  TWS')
    actual=st.text_input('enter actual fuel consumption')       
   
            
    temp=st.text_input('entertemp')
            
    meanDraft=st.text_input('enter meanDraft')
    
    
    if st.button("fuel predection in l/h"):
        pred =fuel_predict([shaftSpeed,TWS,temp,meanDraft])
        st.write(pred)
        #if (int(actual)>int(pred)):
           # st.write("Abnormal fuel consumption")
        
if __name__=='__main__':
    main()